import mysql.connector
from prettytable import PrettyTable

koneksi = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="5220411244")

remote = koneksi.cursor()

class Rental:
    def __init__(self, nama, harga, stok):
        self.nama = nama
        self.harga = harga
        self.stok = stok

class Game(Rental):
    def __init__(self, nama,genre, tipe, harga, stok):
        super().__init__(nama, harga, stok)
        self.genre = genre
        self.tipe = tipe

    def tambah(self):
        query = """
        INSERT INTO game (nama, genre, tipe, harga, stok)
        VALUES (%s, %s, %s, %s, %s)"""
        values = (self.nama, self.genre, self.tipe, self.harga, self.stok)
        remote.execute(query, values)
        koneksi.commit()

    def tampil():
        query = "SELECT * FROM game"
        remote.execute(query)
        games = remote.fetchall()
        table = PrettyTable()
        table.field_names = ["Nama", "Genre", "Tipe", "Harga", "Stok"]
        for game in games:
            table.add_row(game)
        print(table)

    def update(self,new_stok):
        query = """
        UPDATE game
        SET stok = %s
        WHERE nama = %s
        """
        values = (new_stok, self.nama)
        remote.execute(query, values)
        koneksi.commit()

    def hapus(self):
        query = "DELETE FROM game WHERE nama = %s"
        values = (self.nama,)
        remote.execute(query, values)
        koneksi.commit()

class Console(Rental):
    def __init__(self, nama,kondisi, harga, stok):
        super().__init__(nama, harga, stok)
        self.kondisi = kondisi

    def tambah(self):
        query = """
        INSERT INTO console (nama, kondisi, harga, stok)
        VALUES (%s, %s, %s, %s)
        """
        values = (self.nama, self.kondisi, self.harga, self.stok)
        remote.execute(query, values)
        koneksi.commit()

    def tampil():
        query = "SELECT * FROM console"
        remote.execute(query)
        consoles = remote.fetchall()
        table = PrettyTable()
        table.field_names = ["Nama", "Kondisi", "Harga", "Stok"]
        for console in consoles:
            table.add_row(console)
        print(table)

    def update(self,new_stok):
        query = """
        UPDATE console
        SET stok = %s
        WHERE nama = %s
        """
        values = (new_stok, self.nama)
        remote.execute(query, values)
        koneksi.commit()

    def hapus(self):
        query = "DELETE FROM console WHERE nama = %s"
        values = (self.nama,)
        remote.execute(query, values)
        koneksi.commit()

Game.tampil()

game1 = Game("Assassin's Creed Valhalla","Action-Adventure", "Single Player",400000,6)
# game1.tambah()
game2 = Game("Pokemon Legend Arceus","turnbase RPG", "Single Player", 300000, 5)
# game2.tambah()
# Game.tampil()

# game1.update(10)
# game2.update(9)
# Game.tampil()

game1.hapus()
Game.tampil()

# Console.tampil()
console1 = Console("Nintendo Switch V1", "normal", 300000, 12)
# console1.tambah()

console2 = Console("Nintendo WII", "lecet bagian luar", 200000, 2)
# console2.tambah()
# Console.tampil()

# console1.update(14)
# console2.update(4)
# Console.tampil()

console2.hapus()
Console.tampil() 