-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2024 at 04:55 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `5220411244`
--

-- --------------------------------------------------------

--
-- Table structure for table `console`
--

CREATE TABLE `console` (
  `nama` varchar(40) NOT NULL,
  `kondisi` varchar(40) NOT NULL,
  `harga` int(40) NOT NULL,
  `stok` int(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `console`
--

INSERT INTO `console` (`nama`, `kondisi`, `harga`, `stok`) VALUES
('PS 5 ', 'normal', 250000, 5),
('PS 4', 'normal', 200000, 12),
('Nintendo Switch V2', 'normal', 400000, 3),
('Nintendo Switch', 'joystick drifting', 250000, 2),
('PS vita', 'lecet bagian luar', 200000, 3),
('PS 2', 'normal', 100000, 12),
('Nintendo Switch V1', 'normal', 300000, 14);

-- --------------------------------------------------------

--
-- Table structure for table `game`
--

CREATE TABLE `game` (
  `nama` varchar(40) NOT NULL,
  `genre` varchar(40) NOT NULL,
  `tipe` varchar(40) NOT NULL,
  `harga` int(20) NOT NULL,
  `stok` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `game`
--

INSERT INTO `game` (`nama`, `genre`, `tipe`, `harga`, `stok`) VALUES
('Cyberpunk 2077', 'action RPG', 'single player', 200000, 10),
('Pokemon Scarlet version', 'Turn base open world RPG', 'multiplayer', 250000, 20),
('Pokemon Violet Version', 'Turn base open world RPG', 'multiplayer', 250000, 20),
('Mario kart 8 deluxe', 'Racing Game', 'multiplayer', 300000, 14),
('Persona 5 Royal edition ', 'action RPG', 'single player', 250000, 8),
('Persona 5 Strikers', 'action RPG', 'single player', 300000, 8),
('Pokemon Legend Arceus', 'turnbase RPG', 'Single Player', 300000, 9);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
